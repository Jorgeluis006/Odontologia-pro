
CREATE TABLE IF NOT EXISTS odontologos (
  id int auto_increment primary key,
  apellido VARCHAR(255) NOT NULL,
  nombre VARCHAR(255) NOT NULL,
  matricula VARCHAR(20) NOT NULL
);

CREATE TABLE Paciente (
  id int auto_increment primary key,
  nombre VARCHAR(255) NOT NULL,
  apellido VARCHAR(255) NOT NULL,
  domicilio VARCHAR(255) NOT NULL,
  dni VARCHAR(255) NOT NULL,
  fecha_alta DATE NOT NULL
);