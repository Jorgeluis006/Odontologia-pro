
var formulario = document.getElementById("formulario-login");

formulario.addEventListener("submit", function(event) {
  event.preventDefault();

  var usuario = document.getElementById("nombre-usuario").value;
  var contrasena = document.getElementById("contrasena").value;


  var solicitud = new XMLHttpRequest();
  solicitud.onreadystatechange = function() {
    if (this.readyState === 4 && this.status === 200) {
      var respuesta = JSON.parse(this.responseText);

      if (respuesta.autenticado) {

        localStorage.setItem("usuario", JSON.stringify(respuesta.usuario));

        window.location.href = "inicio.html";
      } else {

        var mensajeError = document.getElementById("mensaje-error");
        mensajeError.innerHTML = "Nombre de usuario o contraseña incorrectos";
      }
    }
  };

  solicitud.open("POST", "/login");
  solicitud.setRequestHeader("Content-Type", "application/json");
  solicitud.send(JSON.stringify({ usuario: usuario, contrasena: contrasena }));
});




