package com.example.OdontologiaJ.service;

import com.example.OdontologiaJ.model.Odontologo;
import com.example.OdontologiaJ.repository.Impl.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public abstract class OdontologoServiceImpl implements OdontologoService {
    @Autowired
    private OdontologoService odontologoRepository;
    private final List<Odontologo> odontologos = new ArrayList<>();

    @Override
    public List<Odontologo> listar() {
        return odontologoRepository.findAll();
    }


    @Override
    public Odontologo agregar(Odontologo odontologo) {
        odontologos.add(odontologo);
        return odontologo;
    }

    @Override
    public ResponseEntity<Odontologo> modificar(int matricula, Odontologo odontologoModificado) {
        Odontologo odontologoExistente = odontologos.stream()
                .filter(o -> o.getMatricula() == matricula)
                .findFirst()
                .orElse(null);

        if (odontologoExistente != null) {
            odontologoExistente.setNombre(odontologoModificado.getNombre());
            odontologoExistente.setApellido(odontologoModificado.getApellido());
            return new ResponseEntity<>(odontologoExistente, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public ResponseEntity<Void> eliminar(int matricula) {
        boolean removido = odontologos.removeIf(o -> o.getMatricula() == matricula);

        if (removido) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public Odontologo save(Odontologo var1) {
        return null;
    }

    @Override
    public List findAll() {
        return null;
    }

    @Override
    public Object findById(int var1) {
        return null;
    }

    @Override
    public void deleteById(int var1) {

    }

    @Override
    public void deleteAll() {

    }
}
