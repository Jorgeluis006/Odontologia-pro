package com.example.OdontologiaJ.controller;


import com.example.OdontologiaJ.model.Paciente;
import com.example.OdontologiaJ.repository.Impl.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;

    @GetMapping
    public List<Paciente> listar() {
        return pacienteService.findAll();
    }

    @PostMapping
    public ResponseEntity<Paciente> agregar(@RequestBody Paciente paciente) {
        if (paciente.getId() != null) {
            return ResponseEntity.badRequest().build();
        }
        Paciente pacienteGuardado = pacienteService.save(paciente);
        return ResponseEntity.status(HttpStatus.CREATED).body(pacienteGuardado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Paciente> modificar(@PathVariable Long id, @RequestBody Paciente paciente) {
        Optional<Paciente> pacienteOptional = pacienteService.findById(id);
        if (!pacienteOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        Paciente pacienteExistente = pacienteOptional.get();
        pacienteExistente.setNombre(paciente.getNombre());
        pacienteExistente.setApellido(paciente.getApellido());
        pacienteExistente.setDomicilio(paciente.getDomicilio());
        pacienteExistente.setDni(paciente.getDni());
        pacienteExistente.setFechaAlta(paciente.getFechaAlta());
        pacienteService.save(pacienteExistente);
        return ResponseEntity.ok(pacienteExistente);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        Optional<Paciente> pacienteOptional = pacienteService.findById(id);
        if (!pacienteOptional.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        pacienteService.deleteById(id);
        return ResponseEntity.ok().build();
    }
}