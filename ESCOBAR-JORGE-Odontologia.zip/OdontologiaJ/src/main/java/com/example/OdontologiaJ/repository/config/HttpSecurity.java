package com.example.OdontologiaJ.repository.config;

public class HttpSecurity {
    public Object authorizeRequests() {
        return null;
    }
}
