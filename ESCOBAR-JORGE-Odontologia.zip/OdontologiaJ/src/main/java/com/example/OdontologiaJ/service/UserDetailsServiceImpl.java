package com.example.OdontologiaJ.service;

import com.example.OdontologiaJ.model.Usuario;
import com.example.OdontologiaJ.repository.Impl.UserDetailsService;
import com.example.OdontologiaJ.repository.Impl.UsuarioRepository;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

@Service
public class UserDetailsServiceImpl<UserDetails> implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws Exception {
        Optional<Usuario> optionalUsuario = usuarioRepository.findByUsername(username);
        if (!optionalUsuario.isPresent()) {
            throw new Exception("Usuario no encontrado");
        }
        return null;
    }
}
