package com.example.OdontologiaJ.repository.Impl;

import com.example.OdontologiaJ.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PacienteService extends JpaRepository<Paciente, Long> {

    List<Paciente> listarPacientes();

    Paciente agregarPaciente(Long paciente);

    Paciente modificarPaciente(Long paciente);

    Paciente eliminarPaciente(Long id);


    Optional<Object> buscar(Long id);
}
