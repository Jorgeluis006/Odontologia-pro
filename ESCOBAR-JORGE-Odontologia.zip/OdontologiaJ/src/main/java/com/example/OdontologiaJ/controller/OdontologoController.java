package com.example.OdontologiaJ.controller;

import com.example.OdontologiaJ.model.Odontologo;
import com.example.OdontologiaJ.repository.Impl.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/odontologos")
public class OdontologoController  {
    @Autowired
    private OdontologoService odontologoService;


    @GetMapping("/")
    public List<Odontologo> listarOdontologos() {
        return odontologoService.findAll();
    }

    @PostMapping("/")
    public ResponseEntity<Odontologo> agregarOdontologo(@RequestBody Odontologo odontologo) {
        try {
            Odontologo nuevoOdontologo = odontologoService.save(odontologo);
            return new ResponseEntity<>(nuevoOdontologo, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Odontologo> buscarOdontologoPorId(@PathVariable Long id) {
        Optional<Odontologo> odontologo = odontologoService.findById(id);

        if (odontologo.isPresent()) {
            return new ResponseEntity<>(odontologo.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Odontologo> modificarOdontologo(@PathVariable Long id, @RequestBody Odontologo odontologo) {
        Optional<Odontologo> odontologoEncontrado = odontologoService.findById(id);

        if (odontologoEncontrado.isPresent()) {
            Odontologo odontologoModificado = odontologoEncontrado.get();
            odontologoModificado.setApellido(odontologo.getApellido());
            odontologoModificado.setNombre(odontologo.getNombre());
            odontologoModificado.setMatricula(odontologo.getMatricula());
            return new ResponseEntity<>(odontologoService.save(odontologoModificado), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> eliminarOdontologo(@PathVariable Long id) {
        try {
            odontologoService.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}