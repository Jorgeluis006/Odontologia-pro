package com.example.OdontologiaJ.service;

import com.example.OdontologiaJ.model.Paciente;
import com.example.OdontologiaJ.repository.Impl.PacienteService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;


import java.util.List;


public abstract class PacienteServiceImlp implements PacienteService {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Paciente> listarPacientes() {
        TypedQuery<Paciente> query = entityManager.createQuery("SELECT p FROM Paciente p", Paciente.class);
        return query.getResultList();
    }

    @Override
    public Paciente agregarPaciente(Long paciente) {
        entityManager.persist(paciente);
        return null;
    }

    @Override
    public Paciente modificarPaciente(Long paciente) {
        entityManager.merge(paciente);
        return null;
    }

    @Override
    public Paciente eliminarPaciente(Long id) {
        Paciente paciente = entityManager.find(Paciente.class, id);
        if(paciente != null) {
            entityManager.remove(paciente);
        } else {
            throw new IllegalArgumentException("No se encontró el paciente con id " + id);
        }
        return paciente;
    }

}

