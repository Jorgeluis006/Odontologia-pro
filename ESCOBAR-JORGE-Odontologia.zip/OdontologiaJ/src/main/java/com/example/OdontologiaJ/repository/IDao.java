package com.example.OdontologiaJ.repository;

import com.example.OdontologiaJ.model.Odontologo;

import java.util.List;



public interface IDao <T> {
    static Odontologo save(Odontologo var1) {
        return null;
    }

    List<T> findAll();

    default T findById(int var1) {
        return null;
    }

    void deleteById(int var1);

    void deleteAll();
    T guardar(T t);
    T buscar(Integer id);
    void eliminar(Integer id);
    List<T> buscarTodos();
    T actualizar(T t);
}
