package com.example.OdontologiaJ.repository.Impl;

import com.example.OdontologiaJ.model.Turno;
import com.example.OdontologiaJ.repository.IDao;

import java.util.List;

public interface TurnoService {
    IDao<Turno> turnoRepository = null;

    public default Turno registrarTurno(Turno turno){
        return  turnoRepository.guardar(turno);
    }
    public default List<Turno> listar(){
        return turnoRepository.buscarTodos();
    }
    public default void eliminar(Integer id){
        turnoRepository.eliminar(id);
    }
    public default Turno actualizar(Turno turno){
        return turnoRepository.actualizar(turno);
    }
    public default Turno buscar(Integer id){
        return turnoRepository.buscar(id);
    }
}
