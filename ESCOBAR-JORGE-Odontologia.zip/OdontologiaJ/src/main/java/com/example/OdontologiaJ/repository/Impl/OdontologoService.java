package com.example.OdontologiaJ.repository.Impl;

import com.example.OdontologiaJ.model.Odontologo;
import com.example.OdontologiaJ.repository.IDao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

public interface OdontologoService extends JpaRepository<Odontologo, Long> {
    List<Odontologo> listar();
    Odontologo agregar(Odontologo odontologo);
    ResponseEntity<Odontologo> modificar(int matricula, Odontologo odontologoModificado);
    ResponseEntity<Void> eliminar(int matricula);

    Odontologo save(Odontologo var1);

    Object findById(int var1);

    void deleteById(int var1);

    Optional<Object> buscar(Integer id);
}