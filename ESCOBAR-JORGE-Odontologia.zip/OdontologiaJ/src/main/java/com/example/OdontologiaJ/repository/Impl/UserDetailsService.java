package com.example.OdontologiaJ.repository.Impl;

public interface UserDetailsService {
    Object loadUserByUsername(String username) throws Exception;
}
