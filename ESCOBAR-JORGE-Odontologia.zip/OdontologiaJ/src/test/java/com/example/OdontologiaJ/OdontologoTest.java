package com.example.OdontologiaJ;

import com.example.OdontologiaJ.controller.OdontologoController;
import com.example.OdontologiaJ.model.Odontologo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.awt.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@SpringBootTest
@AutoConfigureTestDatabase
public class OdontologoTest {

    @Autowired
    private OdontologoController odontologoController;



    @Test
    public void testAgregarOdontologo() {
        Odontologo odontologo = new Odontologo(12,"Pérez", "Juan", 12345);
        ResponseEntity<Odontologo> responseEntity = odontologoController.agregarOdontologo(odontologo);
        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody().getId());


    }

    }

