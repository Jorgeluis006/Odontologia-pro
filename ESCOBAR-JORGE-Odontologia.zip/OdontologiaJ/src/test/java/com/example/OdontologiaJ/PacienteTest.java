package com.example.OdontologiaJ;

import com.example.OdontologiaJ.model.Paciente;
import com.example.OdontologiaJ.repository.Impl.PacienteService;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class PacienteTest {

        @Autowired
        private PacienteService pacienteService;

        @Test
        public void testAgregarPaciente() {
            Paciente paciente1 = new Paciente(134,"Juan", "Perez", "Calle Falsa 123", "12345678", LocalDate.now());
            pacienteService.agregarPaciente(paciente1.getId());

            Paciente paciente2 = pacienteService.agregarPaciente(paciente1.getId());
            assertNotNull(paciente2);
            assertEquals("Juan", paciente2.getNombre());
        }

        @Test
        public void testModificarPaciente() {
            Paciente paciente1 = new Paciente(56,"Juan", "Perez", "Calle Falsa 123", "12345678", LocalDate.now());
            pacienteService.agregarPaciente(paciente1.getId());

            Paciente paciente2 = pacienteService.modificarPaciente(paciente1.getId());
            assertNotNull(paciente2);
            assertEquals("Juan", paciente2.getNombre());

            paciente2.setNombre("Pedro");
            paciente2.setApellido("Gonzalez");
            paciente2.setDomicilio("Calle Falsa 456");
            paciente2.setDni("87654321");
            pacienteService.modificarPaciente(paciente2.getId());

            Paciente paciente3 = pacienteService.modificarPaciente(paciente2.getId());
            assertNotNull(paciente3);
            assertEquals("Pedro", paciente3.getNombre());
            assertEquals("Gonzalez", paciente3.getApellido());
            assertEquals("Calle Falsa 456", paciente3.getDomicilio());
            assertEquals("87654321", paciente3.getDni());
        }

        @Test
        public void testEliminarPaciente() {
            Paciente paciente1 = new Paciente(12,"Juan", "Perez", "Calle Falsa 123", "12345678", LocalDate.now());
            pacienteService.agregarPaciente(paciente1.getId());

            Paciente paciente2 = pacienteService.eliminarPaciente(paciente1.getId());
            assertNotNull(paciente2);

            pacienteService.eliminarPaciente(paciente2.getId());

            Paciente paciente3 = pacienteService.eliminarPaciente(paciente2.getId());
            assertNull(paciente3);
        }

        @Test
        public void testListarPacientes() {
            Paciente paciente1 = new Paciente(112,"Juan", "Perez", "Calle Falsa 123", "12345678", LocalDate.now());
            Paciente paciente2 = new Paciente(2,"Pedro", "Gonzalez", "Calle Falsa 456", "87654321", LocalDate.now());
            Paciente paciente3 = new Paciente(2,"Maria", "Gomez", "Calle Falsa 789", "13579246", LocalDate.now());

            pacienteService.agregarPaciente(paciente1.getId());
            pacienteService.agregarPaciente(paciente2.getId());
            pacienteService.agregarPaciente(paciente3.getId());

            List<Paciente> pacientes = pacienteService.listarPacientes();
            assertNotNull(pacientes);
            assertEquals(3, pacientes.size());
        }

    }