package com.example.OdontologiaJ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontologiaJorgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
